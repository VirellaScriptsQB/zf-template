-- zf-banking/server/main.lua
-- Updated for: ATM PIN pre-check + safe Config defaults + (optional) server-side location enforcement

Config = Config or {}

-- ===== Safe defaults (prevents nil errors) =====
Config.pinLength = tonumber(Config.pinLength) or 4
Config.pinSessionSeconds = tonumber(Config.pinSessionSeconds) or 60
Config.maxFailedAttempts = tonumber(Config.maxFailedAttempts) or 5
Config.lockoutSeconds = tonumber(Config.lockoutSeconds) or 120

Config.minAmount = tonumber(Config.minAmount) or 1

Config.metaPin         = Config.metaPin or 'zf_bank_pin'
Config.metaFailed      = Config.metaFailed or 'zf_bank_failed'
Config.metaLockedUntil = Config.metaLockedUntil or 'zf_bank_locked_until'
Config.metaHistory     = Config.metaHistory or 'zf_bank_history'
Config.historyMax      = tonumber(Config.historyMax) or 20

Config.cooldowns = Config.cooldowns or { setpin = 5, deposit = 3, withdraw = 3, transfer = 5 }
Config.limits = Config.limits or {
  bank = { deposit = 50000, withdraw = 50000, transfer = 100000 },
  atm  = { deposit = 20000, withdraw = 10000, transfer = 50000 },
}
Config.fees = Config.fees or {
  bank = {
    deposit  = { percent = 0.0, flat = 0 },
    withdraw = { percent = 0.0, flat = 0 },
    transfer = { percent = 0.0, flat = 50 },
  },
  atm = {
    deposit  = { percent = 0.0, flat = 0 },
    withdraw = { percent = 2.0, flat = 0, min = 10 },
    transfer = { percent = 0.0, flat = 100 },
  }
}

Config.banks = Config.banks or {} -- used for optional location enforcement

-- If true: player must be near a bank zone to get "bank" limits/fees (prevents spoofing via='bank' at an ATM)
Config.enforceLocation = (Config.enforceLocation ~= false)
Config.bankRadius = tonumber(Config.bankRadius) or 3.0

local pinSession = {} ---@type table<number, number>
local cooldowns = {} ---@type table<number, table<string, number>> -- source -> action -> os.time()

---@param src number
---@return Player? player
local function getPlayer(src)
  return exports.qbx_core:GetPlayer(src)
end

local function now()
  return os.time()
end

---@param src number
---@param action string
---@return boolean ok
---@return string? err
local function checkCooldown(src, action)
  local cd = tonumber((Config.cooldowns and Config.cooldowns[action]) or 0) or 0
  if cd <= 0 then return true end

  cooldowns[src] = cooldowns[src] or {}
  local last = cooldowns[src][action] or 0
  local elapsed = now() - last
  if elapsed < cd then
    return false, ('Slow down (%ds).'):format(cd - elapsed)
  end

  cooldowns[src][action] = now()
  return true
end

---@param requested any
---@return 'atm'|'bank'
local function normalizeVia(requested)
  return (requested == 'bank') and 'bank' or 'atm'
end

---@param src number
---@return boolean
local function isNearAnyBank(src)
  if #Config.banks == 0 then return false end

  local ped = GetPlayerPed(src)
  if not ped or ped == 0 then return false end

  local pcoords = GetEntityCoords(ped)
  for _, bank in ipairs(Config.banks) do
    local c = bank.coords
    if c then
      local dist = #(pcoords - c)
      local radius = Config.bankRadius
      if bank.target and bank.target.distance then
        radius = math.max(radius, tonumber(bank.target.distance) or radius)
      end
      if dist <= radius then
        return true
      end
    end
  end

  return false
end

---@param src number
---@param requested any
---@return 'atm'|'bank'
local function resolveVia(src, requested)
  local via = normalizeVia(requested)
  if not Config.enforceLocation then
    return via
  end

  if via == 'bank' and not isNearAnyBank(src) then
    return 'atm'
  end

  return via
end

---@param via 'atm'|'bank'
---@param action 'deposit'|'withdraw'|'transfer'
---@return number limit
local function getLimit(via, action)
  local tbl = (Config.limits and Config.limits[via]) or {}
  return tonumber(tbl[action] or 0) or 0
end

---@param via 'atm'|'bank'
---@param action 'deposit'|'withdraw'|'transfer'
---@param amount number
---@return number fee
local function calcFee(via, action, amount)
  local feeCfg = (Config.fees and Config.fees[via] and Config.fees[via][action]) or {}
  local percent = tonumber(feeCfg.percent or 0) or 0
  local flat = tonumber(feeCfg.flat or 0) or 0
  local min = tonumber(feeCfg.min or 0) or 0

  -- ceil
  local pctFee = math.floor((amount * percent / 100.0) + 0.9999)
  local fee = flat + pctFee
  if fee < min then fee = min end
  if fee < 0 then fee = 0 end
  return fee
end

---@param src number
---@return boolean locked
---@return number lockedUntil
local function isLocked(src)
  local player = getPlayer(src)
  if not player then return true, now() + 999999 end
  local lockedUntil = tonumber(player.Functions.GetMetaData(Config.metaLockedUntil) or 0) or 0
  return lockedUntil > now(), lockedUntil
end

---@param src number
---@return boolean
local function hasSession(src)
  local expires = pinSession[src]
  return expires ~= nil and expires > now()
end

---@param src number
---@param pin string|nil
---@return boolean ok
---@return string? err
local function verifyPin(src, pin)
  local player = getPlayer(src)
  if not player then return false, 'no_player' end

  local locked, lockedUntil = isLocked(src)
  if locked then
    return false, ('Account locked (%ds).'):format(math.max(0, lockedUntil - now()))
  end

  local stored = player.Functions.GetMetaData(Config.metaPin)
  if not stored then return false, 'No PIN set.' end
  if not pin or pin == '' then return false, 'PIN required.' end

  if tostring(pin) ~= tostring(stored) then
    local failed = tonumber(player.Functions.GetMetaData(Config.metaFailed) or 0) or 0
    failed += 1
    player.Functions.SetMetaData(Config.metaFailed, failed)

    if failed >= (Config.maxFailedAttempts or 5) then
      local untilTs = now() + (Config.lockoutSeconds or 120)
      player.Functions.SetMetaData(Config.metaLockedUntil, untilTs)
      return false, ('Too many attempts. Locked for %ds.'):format(Config.lockoutSeconds or 120)
    end

    return false, ('Wrong PIN (%d/%d).'):format(failed, Config.maxFailedAttempts or 5)
  end

  player.Functions.SetMetaData(Config.metaFailed, 0)
  pinSession[src] = now() + (Config.pinSessionSeconds or 60)
  return true
end

---@param src number
---@param pin string|nil
---@return boolean ok
---@return string? err
local function requirePin(src, pin)
  if hasSession(src) then return true end
  return verifyPin(src, pin)
end

---@param player Player
---@param entry table
local function pushHistory(player, entry)
  local hist = player.Functions.GetMetaData(Config.metaHistory)
  if type(hist) ~= 'table' then hist = {} end

  table.insert(hist, 1, entry)

  local max = tonumber(Config.historyMax or 20) or 20
  while #hist > max do
    hist[#hist] = nil
  end

  player.Functions.SetMetaData(Config.metaHistory, hist)
end

-- =========================
-- Callbacks
-- =========================

lib.callback.register('zf-banking:getBalances', function(src, requestedVia)
  local via = resolveVia(src, requestedVia)
  local player = getPlayer(src)
  if not player then return nil end

  local cash = player.Functions.GetMoney('cash') or 0
  local bank = player.Functions.GetMoney('bank') or 0
  local pinSet = player.Functions.GetMetaData(Config.metaPin) ~= nil
  local locked, lockedUntil = isLocked(src)

  return {
    cash = cash,
    bank = bank,
    pinSet = pinSet,
    locked = locked,
    lockedUntil = lockedUntil,
    session = hasSession(src),
    via = via,
  }
end)

lib.callback.register('zf-banking:getHistory', function(src, _requestedVia)
  local player = getPlayer(src)
  if not player then return {} end
  local hist = player.Functions.GetMetaData(Config.metaHistory)
  return type(hist) == 'table' and hist or {}
end)

-- NEW: used by client to require PIN before showing ATM menu
lib.callback.register('zf-banking:verifyPin', function(src, requestedVia, pin)
  local via = resolveVia(src, requestedVia)
  if via ~= 'atm' then
    -- only gate ATMs; banks can open menu freely
    return true
  end

  local ok, err = requirePin(src, pin)
  if not ok then return false, err end
  return true
end)

lib.callback.register('zf-banking:setPin', function(src, requestedVia, pin)
  local ok, err = checkCooldown(src, 'setpin')
  if not ok then return false, err end

  local player = getPlayer(src)
  if not player then return false, 'no_player' end

  local s = tostring(pin or '')
  if #s ~= (Config.pinLength or 4) or s:match('%D') then
    return false, ('PIN must be exactly %d digits.'):format(Config.pinLength or 4)
  end

  player.Functions.SetMetaData(Config.metaPin, s)
  player.Functions.SetMetaData(Config.metaFailed, 0)
  player.Functions.SetMetaData(Config.metaLockedUntil, 0)
  pinSession[src] = now() + (Config.pinSessionSeconds or 60)

  pushHistory(player, { t = now(), type = 'set_pin', amount = 0, fee = 0, via = resolveVia(src, requestedVia) })
  return true
end)

lib.callback.register('zf-banking:deposit', function(src, requestedVia, amount, pin)
  local via = resolveVia(src, requestedVia)

  local ok, err = checkCooldown(src, 'deposit')
  if not ok then return false, err end

  local player = getPlayer(src)
  if not player then return false, 'no_player' end

  amount = math.floor(tonumber(amount) or 0)
  local limit = getLimit(via, 'deposit')
  if amount < Config.minAmount then return false, 'Invalid amount.' end
  if amount > limit then return false, ('Max deposit here is $%d.'):format(limit) end

  ok, err = requirePin(src, pin)
  if not ok then return false, err end

  local fee = calcFee(via, 'deposit', amount)
  local total = amount + fee

  if not player.Functions.RemoveMoney('cash', total, 'zf-banking:deposit') then
    return false, 'Not enough cash (including fee).'
  end

  player.Functions.AddMoney('bank', amount, 'zf-banking:deposit')
  pushHistory(player, { t = now(), type = 'deposit', amount = amount, fee = fee, via = via })
  return true
end)

lib.callback.register('zf-banking:withdraw', function(src, requestedVia, amount, pin)
  local via = resolveVia(src, requestedVia)

  local ok, err = checkCooldown(src, 'withdraw')
  if not ok then return false, err end

  local player = getPlayer(src)
  if not player then return false, 'no_player' end

  amount = math.floor(tonumber(amount) or 0)
  local limit = getLimit(via, 'withdraw')
  if amount < Config.minAmount then return false, 'Invalid amount.' end
  if amount > limit then return false, ('Max withdraw here is $%d.'):format(limit) end

  ok, err = requirePin(src, pin)
  if not ok then return false, err end

  local fee = calcFee(via, 'withdraw', amount)
  local total = amount + fee

  if not player.Functions.RemoveMoney('bank', total, 'zf-banking:withdraw') then
    return false, 'Not enough bank (including fee).'
  end

  player.Functions.AddMoney('cash', amount, 'zf-banking:withdraw')
  pushHistory(player, { t = now(), type = 'withdraw', amount = amount, fee = fee, via = via })
  return true
end)

lib.callback.register('zf-banking:transfer', function(src, requestedVia, target, amount, pin)
  local via = resolveVia(src, requestedVia)

  local ok, err = checkCooldown(src, 'transfer')
  if not ok then return false, err end

  local player = getPlayer(src)
  if not player then return false, 'no_player' end

  amount = math.floor(tonumber(amount) or 0)
  local limit = getLimit(via, 'transfer')
  if amount < Config.minAmount then return false, 'Invalid amount.' end
  if amount > limit then return false, ('Max transfer here is $%d.'):format(limit) end

  ok, err = requirePin(src, pin)
  if not ok then return false, err end

  local targetPlayer
  local targetId = tonumber(target)
  if targetId then
    targetPlayer = exports.qbx_core:GetPlayer(targetId)
  else
    targetPlayer = exports.qbx_core:GetPlayerByCitizenId(tostring(target))
  end

  if not targetPlayer or not targetPlayer.PlayerData or not targetPlayer.PlayerData.source then
    return false, 'Target not found.'
  end
  if targetPlayer.PlayerData.source == src then
    return false, 'You can’t transfer to yourself.'
  end

  local fee = calcFee(via, 'transfer', amount)
  local total = amount + fee

  if not player.Functions.RemoveMoney('bank', total, 'zf-banking:transfer') then
    return false, 'Not enough bank (including fee).'
  end

  targetPlayer.Functions.AddMoney('bank', amount, 'zf-banking:transfer')

  pushHistory(player, { t = now(), type = 'transfer_out', amount = amount, fee = fee, via = via, target = tostring(target) })
  pushHistory(targetPlayer, { t = now(), type = 'transfer_in', amount = amount, fee = 0, via = via, from = tostring(src) })

  return true
end)

AddEventHandler('playerDropped', function()
  pinSession[source] = nil
  cooldowns[source] = nil
end)
