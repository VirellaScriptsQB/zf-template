-- =========================
-- ZF TEMPLATE CLIENT
-- Wrappers for zf-notify / zf-ui / zf-minigame
-- =========================

local function rs(name)
  return GetResourceState(name) == 'started'
end

local function mapType(t)
  t = tostring(t or 'info'):lower()
  if t == 'inform' or t == 'primary' then return 'info' end
  if t == 'warn' then return 'warning' end
  if t == 'success' or t == 'error' or t == 'warning' or t == 'info' then return t end
  return 'info'
end

-- ✅ Notify wrapper (prefers zf-notify, fallback to zf-ui Notify if you have it)
local function Notify(message, nType, duration, title)
  local payload = {
    title = title or Config.NotifyTitle or 'ZF',
    message = tostring(message or ''),
    type = mapType(nType),
    duration = tonumber(duration) or 3000
  }

  if rs('zf-notify') then
    local ok = pcall(function()
      exports['zf-notify']:Notify(payload)
    end)
    if ok then return end
  end

  if rs('zf-ui') then
    local ok = pcall(function()
      if exports['zf-ui'].Notify then
        exports['zf-ui']:Notify(payload)
      end
    end)
    if ok then return end
  end

  print(('[zf-template notify] %s: %s'):format(payload.title, payload.message))
end

-- ✅ Confirm wrapper (zf-ui)
local function Confirm(title, message, confirmLabel, cancelLabel)
  if not rs('zf-ui') then
    Notify('zf-ui is not started (Confirm unavailable).', 'warning')
    return false
  end

  local ok, res = pcall(function()
    return exports['zf-ui']:Confirm({
      title = title or 'Confirm',
      message = message or 'Are you sure?',
      confirmLabel = confirmLabel or 'Confirm',
      cancelLabel = cancelLabel or 'Cancel'
    })
  end)

  if not ok then
    Notify('Confirm failed (UI error).', 'error')
    return false
  end

  return res == true
end

-- ✅ Input wrapper (zf-ui)
local function Input(title, fields)
  if not rs('zf-ui') then
    Notify('zf-ui is not started (Input unavailable).', 'warning')
    return nil
  end

  local ok, res = pcall(function()
    return exports['zf-ui']:Input({
      title = title or 'Input',
      fields = fields or {}
    })
  end)

  if not ok then
    Notify('Input failed (UI error).', 'error')
    return nil
  end

  return res
end

-- ✅ Minigame wrapper (zf-minigame)
local function Minigame(opts)
  if not rs('zf-minigame') then
    Notify('zf-minigame is not started (Minigame unavailable).', 'warning')
    return false
  end

  local ok, res = pcall(function()
    return exports['zf-minigame']:Start(opts or {})
  end)

  if not ok then
    Notify('Minigame failed (export error).', 'error')
    return false
  end

  return res == true
end

-- =========================
-- Example: client->server event
-- =========================
local function ExampleServerAction(data)
  TriggerServerEvent('zf-template:server:exampleAction', data)
end

RegisterNetEvent('zf-template:client:exampleResult', function(ok, msg)
  Notify(msg or (ok and 'Server action success.' or 'Server action failed.'), ok and 'success' or 'error')
end)

-- =========================
-- Test command (runs all layers)
-- /zftest
-- =========================
RegisterCommand(Config.TestCommand, function()
  CreateThread(function()
    Notify('Template test started.', 'info')

    local ok = Confirm('ZF Template', 'Run the full template test?', 'Run', 'Cancel')
    if not ok then
      return Notify('Test cancelled.', 'warning')
    end

    local input = Input('Template Input', {
      { type = 'input', label = 'Reason', required = true, placeholder = 'Type something...' },
      { type = 'number', label = 'Amount', required = false, placeholder = 'Optional' }
    })

    if not input then
      Notify('Input cancelled.', 'warning')
    else
      Notify(('Input saved: %s'):format(tostring(input[1])), 'success')
    end

    local mgOk = Minigame({
      title = (Config.Minigame and Config.Minigame.title) or 'Skillcheck',
      hint = (Config.Minigame and Config.Minigame.hint) or 'Press SPACE',
      speed = (Config.Minigame and Config.Minigame.speed) or 1.0,
      zoneSize = (Config.Minigame and Config.Minigame.zoneSize) or 0.12,
      roundTime = (Config.Minigame and Config.Minigame.roundTime) or 9000
    })

    Notify(mgOk and 'Minigame success ✅' or 'Minigame failed ❌', mgOk and 'success' or 'error')

    -- call server example
    ExampleServerAction({
      reason = input and input[1] or 'no reason',
      amount = input and tonumber(input[2]) or 0,
      minigame = mgOk
    })
  end)
end, false)

-- =========================
-- Exports so other scripts can use template wrappers if you want
-- =========================
exports('Notify', Notify)
exports('Confirm', Confirm)
exports('Input', Input)
exports('Minigame', Minigame)
