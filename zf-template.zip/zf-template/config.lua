Config = {}

-- Command to test the template end-to-end
Config.TestCommand = 'zftest'

-- Default notify title for this resource
Config.NotifyTitle = 'ZF Template'

-- Minigame defaults for the test command
Config.Minigame = {
  title = 'Template Skillcheck',
  hint = 'Press SPACE/ENTER in the zone (ESC cancels)',
  speed = 0.95,
  zoneSize = 0.13,
  roundTime = 9000
}
