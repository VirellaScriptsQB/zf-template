fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'zf-template'
author 'Virella.scripts'
description 'ZF Template: notify/ui/minigame wrappers + clean event patterns'
version '1.0.0'

dependencies {
  'zf-core'
}

shared_scripts {
  'config.lua'
}

client_scripts {
  'client/main.lua'
}

server_scripts {
  'server/main.lua'
}
